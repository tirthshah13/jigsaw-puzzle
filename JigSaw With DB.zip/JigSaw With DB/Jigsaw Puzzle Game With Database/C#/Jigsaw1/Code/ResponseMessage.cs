﻿using System;

namespace MinThantSin.OpenSourceGames
{
    public class ResponseMessage
    {
        public bool Okay { get; set; }
        public string Message { get; set; }
    }
}
