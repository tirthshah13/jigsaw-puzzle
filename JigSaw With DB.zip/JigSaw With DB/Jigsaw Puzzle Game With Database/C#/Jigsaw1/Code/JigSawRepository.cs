﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using Oracle.DataAccess.Client;
using System.Data;
using Oracle.DataAccess.Types;

namespace MinThantSin.OpenSourceGames.Code
{
    class JigSawRepository
    {

        public List<QuestionAnswerModel> GetJigSawQuestions(string type)
        {
            string ConnectionString = ConfigurationManager.ConnectionStrings["WordCloudConnection"].ConnectionString;

            List<QuestionAnswerModel> qaList = new List<QuestionAnswerModel>();
            QuestionAnswerModel singleQa;

            using (OracleConnection connection = new OracleConnection(ConnectionString))
            {
                using (OracleCommand command = connection.CreateCommand())
                {
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }
                    command.CommandType = CommandType.Text;
                    command.CommandText = @"SELECT * FROM JIGSAW_QA WHERE QUESTION_TYPE = '" + type + "'";

                    using (OracleDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            singleQa = new QuestionAnswerModel();

                            if (!reader.IsDBNull(reader.GetOrdinal("QUESTION_ID")))
                            {
                                singleQa.id = reader.GetInt32(reader.GetOrdinal("QUESTION_ID"));
                            }
                            if (!reader.IsDBNull(reader.GetOrdinal("QUESTION")))
                            {
                                singleQa.Question = reader.GetString(reader.GetOrdinal("QUESTION"));
                            }
                            if (!reader.IsDBNull(reader.GetOrdinal("QUESTION_TYPE")))
                            {
                                singleQa.Type = reader.GetString(reader.GetOrdinal("QUESTION_TYPE"));
                            }
                            if (!reader.IsDBNull(reader.GetOrdinal("ANSWER_BYTE")))
                            {
                                OracleBlob blob = reader.GetOracleBlob(reader.GetOrdinal("ANSWER_BYTE"));
                                byte[] imageByte = null;
                                if (!blob.IsNull)
                                {
                                    imageByte = new byte[blob.Length];
                                    blob.Read(imageByte, 0, (int)blob.Length);
                                }
                                singleQa.AnswerByte = imageByte;
                            }

                            qaList.Add(singleQa);
                        }
                    }
                }
            }

            return qaList;
        }

        public void InsertJigSawQA(QuestionAnswerModel QA)
        {
            string ConnectionString = ConfigurationManager.ConnectionStrings["WordCloudConnection"].ConnectionString;

            using (OracleConnection connection = new OracleConnection(ConnectionString))
            {
                using (OracleCommand command = connection.CreateCommand())
                {
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }
                    command.CommandType = CommandType.Text;
                    command.CommandText = "INSERT INTO JIGSAW_QA (QUESTION_ID,QUESTION,QUESTION_TYPE,ANSWER_BYTE) values(:param_id,:param_question,:param_type,:param_byte)";

                    OracleParameter paramID = command.Parameters.Add("param_id", OracleDbType.Int32);
                    paramID.Direction = ParameterDirection.Input;
                    paramID.Value = QA.id;

                    OracleParameter paramQuestion = command.Parameters.Add("param_question", OracleDbType.Varchar2);
                    paramQuestion.Direction = ParameterDirection.Input;
                    paramQuestion.Value = QA.Question;

                    OracleParameter paramType = command.Parameters.Add("param_type", OracleDbType.Varchar2);
                    paramType.Direction = ParameterDirection.Input;
                    paramType.Value = QA.Type;

                    OracleParameter paramByte = command.Parameters.Add("param_byte", OracleDbType.Blob);
                    paramByte.Direction = ParameterDirection.Input;
                    paramByte.Value = QA.AnswerByte;
                    
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
