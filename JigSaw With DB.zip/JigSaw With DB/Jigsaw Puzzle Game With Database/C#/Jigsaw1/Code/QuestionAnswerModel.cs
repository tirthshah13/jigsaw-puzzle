﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MinThantSin.OpenSourceGames.Code
{
    class QuestionAnswerModel
    {

        public int id { get; set; }

        public string Question { get; set; }

        public byte[] AnswerByte { get; set; }

        public string Type { get; set; }

    }
}
