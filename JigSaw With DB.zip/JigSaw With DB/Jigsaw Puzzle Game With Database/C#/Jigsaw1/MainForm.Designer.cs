﻿namespace MinThantSin.OpenSourceGames
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.FileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cPuzzlaeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.javaPuzzleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ExitMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showImageHintToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.QuestionLabel = new System.Windows.Forms.Label();
            this.CountDown_Timer = new System.Windows.Forms.Timer(this.components);
            this.TimerLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Hint_Timer = new System.Windows.Forms.Timer(this.components);
            this.Hint_Label = new System.Windows.Forms.Label();
            this.NextPuzzleBtn = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Image Files|*.png;*.jpg;*.jpeg;*.jpe;*.bmp;*.gif";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FileMenu,
            this.optionsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(16, 4, 0, 4);
            this.menuStrip1.Size = new System.Drawing.Size(1658, 32);
            this.menuStrip1.TabIndex = 0;
            // 
            // FileMenu
            // 
            this.FileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OpenFileMenuItem,
            this.toolStripSeparator1,
            this.ExitMenuItem});
            this.FileMenu.Name = "FileMenu";
            this.FileMenu.Size = new System.Drawing.Size(44, 24);
            this.FileMenu.Text = "&File";
            // 
            // OpenFileMenuItem
            // 
            this.OpenFileMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cPuzzlaeToolStripMenuItem,
            this.javaPuzzleToolStripMenuItem});
            this.OpenFileMenuItem.Name = "OpenFileMenuItem";
            this.OpenFileMenuItem.Size = new System.Drawing.Size(206, 26);
            this.OpenFileMenuItem.Text = "Choose Category...";
            this.OpenFileMenuItem.Click += new System.EventHandler(this.OpenFileMenuItem_Click);
            // 
            // cPuzzlaeToolStripMenuItem
            // 
            this.cPuzzlaeToolStripMenuItem.Name = "cPuzzlaeToolStripMenuItem";
            this.cPuzzlaeToolStripMenuItem.Size = new System.Drawing.Size(202, 26);
            this.cPuzzlaeToolStripMenuItem.Text = "1)Software Puzzle";
            this.cPuzzlaeToolStripMenuItem.Click += new System.EventHandler(this.cPuzzlaeToolStripMenuItem_Click);
            // 
            // javaPuzzleToolStripMenuItem
            // 
            this.javaPuzzleToolStripMenuItem.Name = "javaPuzzleToolStripMenuItem";
            this.javaPuzzleToolStripMenuItem.Size = new System.Drawing.Size(202, 26);
            this.javaPuzzleToolStripMenuItem.Text = "2) Agile Puzzle";
            this.javaPuzzleToolStripMenuItem.Click += new System.EventHandler(this.javaPuzzleToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(203, 6);
            // 
            // ExitMenuItem
            // 
            this.ExitMenuItem.Name = "ExitMenuItem";
            this.ExitMenuItem.Size = new System.Drawing.Size(206, 26);
            this.ExitMenuItem.Text = "E&xit";
            this.ExitMenuItem.Click += new System.EventHandler(this.ExitMenuItem_Click);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showImageHintToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(73, 24);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // showImageHintToolStripMenuItem
            // 
            this.showImageHintToolStripMenuItem.Name = "showImageHintToolStripMenuItem";
            this.showImageHintToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.showImageHintToolStripMenuItem.Text = "Next Question...";
            this.showImageHintToolStripMenuItem.Click += new System.EventHandler(this.showImageHintToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(134, 26);
            this.aboutToolStripMenuItem.Text = "About...";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // QuestionLabel
            // 
            this.QuestionLabel.AutoSize = true;
            this.QuestionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuestionLabel.Location = new System.Drawing.Point(469, 52);
            this.QuestionLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.QuestionLabel.Name = "QuestionLabel";
            this.QuestionLabel.Size = new System.Drawing.Size(0, 29);
            this.QuestionLabel.TabIndex = 1;
            // 
            // CountDown_Timer
            // 
            this.CountDown_Timer.Interval = 1000;
            this.CountDown_Timer.Tick += new System.EventHandler(this.CountDown_Timer_Tick);
            // 
            // TimerLabel
            // 
            this.TimerLabel.AutoSize = true;
            this.TimerLabel.ForeColor = System.Drawing.Color.DarkOrchid;
            this.TimerLabel.Location = new System.Drawing.Point(1250, 35);
            this.TimerLabel.Name = "TimerLabel";
            this.TimerLabel.Size = new System.Drawing.Size(81, 29);
            this.TimerLabel.TabIndex = 2;
            this.TimerLabel.Text = "05:00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.DeepPink;
            this.label1.Location = new System.Drawing.Point(1024, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Time Remaining :";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Hint_Timer
            // 
            this.Hint_Timer.Interval = 1000;
            this.Hint_Timer.Tick += new System.EventHandler(this.Hint_Timer_Tick);
            // 
            // Hint_Label
            // 
            this.Hint_Label.AutoSize = true;
            this.Hint_Label.Location = new System.Drawing.Point(1322, 94);
            this.Hint_Label.Name = "Hint_Label";
            this.Hint_Label.Size = new System.Drawing.Size(0, 29);
            this.Hint_Label.TabIndex = 4;
            // 
            // NextPuzzleBtn
            // 
            this.NextPuzzleBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NextPuzzleBtn.ForeColor = System.Drawing.Color.Crimson;
            this.NextPuzzleBtn.Location = new System.Drawing.Point(1337, 35);
            this.NextPuzzleBtn.Name = "NextPuzzleBtn";
            this.NextPuzzleBtn.Size = new System.Drawing.Size(167, 46);
            this.NextPuzzleBtn.TabIndex = 5;
            this.NextPuzzleBtn.Text = "Next Puzzle";
            this.NextPuzzleBtn.UseVisualStyleBackColor = true;
            this.NextPuzzleBtn.Click += new System.EventHandler(this.NextPuzzleBtn_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MinThantSin.OpenSourceGames.Properties.Resources.Time_Management_PPT_Templates1;
            this.ClientSize = new System.Drawing.Size(1658, 966);
            this.Controls.Add(this.NextPuzzleBtn);
            this.Controls.Add(this.Hint_Label);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TimerLabel);
            this.Controls.Add(this.QuestionLabel);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(9, 7, 9, 7);
            this.MinimumSize = new System.Drawing.Size(1676, 1013);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jigsaw Puzzle";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ClientSizeChanged += new System.EventHandler(this.MainForm_ClientSizeChanged);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.MainForm_Paint);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseUp);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem FileMenu;
        private System.Windows.Forms.ToolStripMenuItem OpenFileMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem ExitMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showImageHintToolStripMenuItem;
        private System.Windows.Forms.Label QuestionLabel;
        private System.Windows.Forms.Timer CountDown_Timer;
        private System.Windows.Forms.Label TimerLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer Hint_Timer;
        private System.Windows.Forms.Label Hint_Label;
        private System.Windows.Forms.ToolStripMenuItem cPuzzlaeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem javaPuzzleToolStripMenuItem;
        private System.Windows.Forms.Button NextPuzzleBtn;
    }
}

